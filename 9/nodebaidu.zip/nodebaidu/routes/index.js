var express = require('express');
var router = express.Router();
var mysql = require('mysql');
/* 首页新闻加载 */
router.get('/', function(req, res, next) {
    var connection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'baidu_news'
    });

    connection.connect();
    var sql = "select * from news";
    connection.query(sql, function(error, results, fields) {
        if (error) throw error;
        res.json(results);
    });

    connection.end();
});

module.exports = router;
