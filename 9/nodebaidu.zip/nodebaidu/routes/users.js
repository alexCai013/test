var express = require('express');
var router = express.Router();
var mysql = require('mysql');
var connection = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'baidu_news'
});
//取得新闻
router.get('/getnews', function(req, res, next) {
    var sql = "select * from news order by id desc";
    connection.query(sql, function(error, results, fields) {
        res.json(results);
    });
});

// 更新新闻
router.post('/update', function(req, res, next) {
    var newsid = req.body.id;
    var newstype = req.body.newstype;
    var newstitle = req.body.newstitle;
    var newsimg = req.body.newsimg;
    var newstime = req.body.newstime;
    var newssrc = req.body.newssrc;
    var sql = "UPDATE news SET newstitle=?,newstype=?,newsimg=?,newstime=?,newssrc=? WHERE id=?";
    connection.query(sql, [newstitle, newstype, newsimg, newstime, newssrc, newsid], function(error, results, fields) {
        res.json(results);
    });
});

// 删除新闻
router.post('/del', function(req, res, next) {
    var newsid = req.body.newsid;
    var sql = "DELETE FROM news WHERE id = ?";
    connection.query(sql, [newsid], function(error, results, fields) {
        res.json(results);
    });
});

// 添加新闻
router.post('/insert', function(req, res, next) {
    var newstype = req.body.newstype;
    var newstitle = req.body.newstitle;
    var newsimg = req.body.newsimg;
    var newstime = req.body.newstime;
    var newssrc = req.body.newssrc;
    var sql = "INSERT INTO news (newstype,newstitle,newsimg,newstime,newssrc) VALUES (?,?,?,?,?)";
    connection.query(sql, [newstype, newstitle, newsimg, newstime, newssrc], function(error, results, fields) {
        res.json(results);
    });
});
module.exports = router;
